[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/LheaSxlu)
# Lab03: 

# 💥 Clone this repo
Before starting the project: **Clone the repo** to your local machine:  
   - Copy the repo link (green "Code" button).
   - **Navigate to the folder**: `cd CS5008` and then `mkdir Lab 3"`, then `cd "Lab 3"`, then run
     ```bash
     git clone <link>  
     ```  

As you continue working on the project:
1. **Make changes** in your local files.
2. **Stage** those changes with `git add`.
3. **Commit** the changes with `git commit -m "message"`.
4. **Push** the changes back to GitHub with `git push`.
---

# 💥 Costumize Command Line: Program Arguments
Programs, especially command line programs, have arguments that are passed into them, and based on those arguments it changes how the program runs. 

For example: 

* `ls -l` on the linux/macOS command line will list the files in the current directory in a long format. 
* `gcc -g -Wall my_file.c -o my_file.out` will compile the file my_file.c into an executable called my_file.out

Everything after the program name, is an argument!  

In c programming, you will notice the main function as two optional arguments

```c
int main(int argc, char** argv){
    // code goes here
}
```

* argc (argument count): An integer representing the number of command-line arguments passed to the program, including the program name itself.  It is always at least 1
* argv (argument vector): An array of character pointers (strings) containing the actual arguments passed to the program. The first element (argv[0]) is always the program name, followed by the remaining arguments.

* in short: argc is the number of arguments being passed into your program from the command line (including the name of the program) and argv is the array of arguments.

### Example:
```bash
#include<stdio.h>


// argc is the number of arguments
// argv us an array of strings holding each argument
// (note that each argument is passed as a string)

int main(int argc, char *argv[]){

// Print the number of arguments passed to our program */
printf("argc = %d\n", argc);

// Print out each argument
for (int i=0; i<argc; i++){
    printf("argv[%d] = %s\n", i, argv[i]);
}
return 0;
}
```
💫 Task 💫 Write this program in the command line to prints out all of the arguments passed into it. Make it so at least one argument is passed into it. For example:

```c
./a.out here are some arguments 1 2 3 4
```

-------------------------------------------------------
# 💥 Sorting (Part 1: Quadtaric Sorting)
For this activity you will be writing a simple bubble sort, while discussing about sorts and BigO. A bubble sort is one of three sorts we will write this module, with the other two also being quadratic  sorts ($O(n^2)$): insertion and selection. 

Sorts are often openly available online, so the real key is understanding which sort to use in which situation.

## 💥  Bubble Sort
Bubble Sort is one of the oldest sorts, and if you line people up asking them to sort by their names, they will often default to a bubble sort. 

The idea behind a bubble sort is that you compare two side by side numbers, swapping them if the right is lower than the left. It is also worth noting the bubble sort is an in place sort, meaning you can sort the array modifying it directly. 

💫 Task 💫  Practice with your group, take turns writing out 5 values, then write out what the array looks like after 1 complete pass. 

For example:
```text
4 2 1 3 5
2 1 3 4 5
1 2 3 4 5
1 2 3 4 5
1 2 3 4 5
```

For five values, you will have five rows even if the sort looks complete to humans, computers still need to check the values. 



💫 Task 💫 Writing Code and Running It
To get started, download the associated code:

* [sort_helper.h](sort_helper.h)
* [sorts.h](sorts.h)
* [tester.c](tester.c) 

A **header file** is used to declare functions, macros, constants, and types that can be shared across multiple .c source files. It ensures consistency and makes the code modular and reusable. Instead of rewriting the same declarations in every file, you include the header file, simplifying code management and reducing errors.

   * `#ifndef SORTS_H` (If Not Defined): Checks if `SORTS_H` is not already defined.


   * `#define SORTS_H` (Define the Symbol): Defines the symbol to prevent multiple inclusions of the file.

   * `#endif`: Marks the end of the block, ensuring the header is included only once.

**Note**: 
Header file contain declaration and helper file contains implementaion of the functions.In this case, the functions are implemented in the header file (.h) but sometimes they are separated between header declarations (.h) and source files (.c)

When you compile your code, you will be compiling from tester.c

```console
> gcc -Wall tester.c -o tester.out
```

To run your bubble sort, it would be something like the following
```text
> ./tester.out 0 5 print
```
Ptint is  flag indicating whether to print the array after each iteration. Print is optional, but is great for figuring out each stage, like above in the example. The first number tells the program which sort to run  
     
0 = bubble sort  
1 = a sort built into the c stdlib. 

The second number is the number of random numbers you want generated.

💫 Task 💫 Testing current code
Right now, the bubble sort doesn't work! (you have to write it). But the sort built into C does work. As such, you can test  `tester.c` with the following

```text
> gcc -Wall tester.c -o tester.out
> ./tester.out 1 10000
```
(the print doesn't work with the built in c library as it isn't an option.)

💫 Task 💫  Writing Swap 
To write the bubble sort, the first you need to do is write a 'swap' function.  The template has been provided in `sort_helper.h`.

```c
void swap(int *a, int *b)
{
    // TODO: Swap two integers in an array.
}
```

The idea is to take two values and swap, so if a comes in with 20, and b comes in with 10, by the end of the function a will be 10, and b will be 20. You can create a temp pointer. 

Go ahead and work on this as a group. 

💫 Task 💫  Writing Bubble Sort 
While bubble sort is well documented you should try writing it, talking it through with your partners. A bubble sort will be two nested for loops. One that goes through the entire array, and one that is performing the swaps on each number. The print should be setup in the 'outer-loop' so you can see what the array looks like after each pass. Don't forget to put `if(print)` before your print, or your code may slow down considerably when you are testing large arrays. 


---
## 💥  Deeper Understanding
💫 Task 💫  As you write the bubble sort, make sure to comment on each line what it is doing and why. Bubble sore is well documented, so it is more important that you understand the why than coming up with a creative solution. 

1. Bubble sort is $O(n^2)$. Looking at the algorithm can you explain to your group why that is?
2. Can you come up with an array that will generate the "worst case"? 
3. Can you come up with an array that will generate the "best case"?
   * By default, the best case is the same, but can you optimize it?
   * Given the example above, optimize it so it stops running after the array is sorted? 
     * The optimized version is more common, and gives us the "best case".

---
## 💥 Compare Sorts

💫 Task 💫 Compare the bubble sort against the other sort provided in C using tester. Try it with various sized arrays. You may want to write down the attempts. 


For example:
| N | Bubble |  Quick |
| :-- | :--: | :--: |
| 10 | 0.05 | 0.001 |
| 100 | 0.5 | 0.01 |
| 1000 | 5 |  0.1 |
| 5000 | ... | ... |

We suggest you run it *without* print, as print will slow down the code. So for example, your run code would look like:

```text
> ./tester.out 0 10000
> ./tester.out 1 10000
```

You will notice on larger numbers, the bubble starts to really slow down, while the qsort (quick sort) doesn't.  Have one member store the runs of the output into a spreadsheet, and then graph the results between the two sorts. 

Work each one out on paper - similar to how you did for the 5 value array above for bubble sort. Make you use the [visualize] tool to better understand!



---
## 💥  Resources
* [Bubble Sort on Wikipedia](https://en.wikipedia.org/wiki/Bubble_sort)
* [Bubble by Geeks for Geeks](https://www.geeksforgeeks.org/bubble-sort/)

[bubble]: https://upload.wikimedia.org/wikipedia/commons/c/c8/Bubble-sort-example-300px.gif
[visualize]: https://www.hackerearth.com/practice/algorithms/sorting/bubble-sort/visualize/

---
## 💥  Submission 
- Commit your changes frequently to your repository to maintain a clean version history.
- Take a screenshot of your terminal showing the complete sequence of commands you used (e.g., git add, git commit, git push, etc.).
- Upload your code and the screenshots (one showing the git clone command and the other with the final sequence of commands) to Gradescope.
---
